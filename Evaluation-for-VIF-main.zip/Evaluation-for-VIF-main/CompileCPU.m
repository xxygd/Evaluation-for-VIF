% Compiling for CPU
addpath matlab
vl_compilenn
